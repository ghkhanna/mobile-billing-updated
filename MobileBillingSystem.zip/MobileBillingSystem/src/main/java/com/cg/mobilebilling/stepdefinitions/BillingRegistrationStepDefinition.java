package com.cg.mobilebilling.stepdefinitions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.mobilebilling.pagebeans.RegistrationPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class BillingRegistrationStepDefinition {
	private WebDriver driver;
	private RegistrationPage registrationPage;
	@Given("^User clicks on registration button on index page$")
	public void user_clicks_on_registration_button_on_index_page() throws Throwable {
		System.setProperty("wendriver.chrome.driver", "D:\\");
		driver = new ChromeDriver();
		driver.get("http://localhost:5555/registration");
		registrationPage=PageFactory.initElements(driver,RegistrationPage.class);
	}

	@When("^User enters valid credentials$")
	public void user_enters_valid_credentials() throws Throwable {
		registrationPage.setFirstName("Ghazal");
		registrationPage.setLastName("Khanna");
		registrationPage.setEmailID("ghazalkhanna@gmail.com");
		registrationPage.setDateOfBirth("08-09-1995");
		registrationPage.setPincode("4110057");
		registrationPage.setCity("Pune");
		registrationPage.setState("Maharashtra");
		registrationPage.clickSubmit();
	}

	@Then("^Register user as a customer$")
	public void register_user_as_a_customer() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Controller Adviser Page";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User enters empty firstname$")
	public void user_enters_empty_firstname() throws Throwable {
		registrationPage.setFirstName("");
		registrationPage.setLastName("Khanna");
		registrationPage.setEmailID("ghazalkhanna@gmail.com");
		registrationPage.setDateOfBirth("08-09-1995");
		registrationPage.setPincode("4110057");
		registrationPage.setCity("Pune");
		registrationPage.setState("Maharashtra");
		registrationPage.clickSubmit();
	}

	@Then("^display empty first name error message$")
	public void display_empty_first_name_error_message() throws Throwable {
		String expectedErrorMessage = "must not be empty";
		Assert.assertEquals(expectedErrorMessage,registrationPage.getActualFirstNameErrorMessage());
	}

	@When("^User enters empty lastname$")
	public void user_enters_empty_lastname() throws Throwable {
		registrationPage.setFirstName("Ghazal");
		registrationPage.setLastName("");
		registrationPage.setEmailID("ghazalkhanna@gmail.com");
		registrationPage.setDateOfBirth("08-09-1995");
		registrationPage.setPincode("4110057");
		registrationPage.setCity("Pune");
		registrationPage.setState("Maharashtra");
		registrationPage.clickSubmit();
	}

	@Then("^display empty last name error message$")
	public void display_empty_last_name_error_message() throws Throwable {
		String expectedErrorMessage = "must not be empty";
		Assert.assertEquals(expectedErrorMessage,registrationPage.getActualLastNameErrorMessage());
	}

	@When("^User enters empty email id$")
	public void user_enters_empty_email_id() throws Throwable {
		registrationPage.setFirstName("Ghazal");
		registrationPage.setLastName("Khanna");
		registrationPage.setEmailID("");
		registrationPage.setDateOfBirth("08-09-1995");
		registrationPage.setPincode("4110057");
		registrationPage.setCity("Pune");
		registrationPage.setState("Maharashtra");
		registrationPage.clickSubmit();
	}

	@Then("^display empty email id error message$")
	public void display_empty_email_id_error_message() throws Throwable {
		String expectedErrorMessage = "must not be empty";
		Assert.assertEquals(expectedErrorMessage,registrationPage.getActualEmailIDErrorMessage());
	}

	@When("^User enters empty date of birth$")
	public void user_enters_empty_date_of_birth() throws Throwable {
		registrationPage.setFirstName("Ghazal");
		registrationPage.setLastName("Khanna");
		registrationPage.setEmailID("ghazalkhanna@gmail.com");
		registrationPage.setDateOfBirth("");
		registrationPage.setPincode("4110057");
		registrationPage.setCity("Pune");
		registrationPage.setState("Maharashtra");
		registrationPage.clickSubmit();
	}

	@Then("^display empty date of birth error message$")
	public void display_empty_date_of_birth_error_message() throws Throwable {
		String expectedErrorMessage = "must not be empty";
		Assert.assertEquals(expectedErrorMessage,registrationPage.getActualDateOfBirthErrorMessage());
	}
}