package com.cg.mobilebilling.stepdefinitions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.CustomerDetailsPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomerDetailsDisplayStepDefinition {
	private WebDriver driver;
	private CustomerDetailsPage customerDetailsPage;
	@Given("^User is on view customer details page$")
	public void user_is_on_view_customer_details_page() throws Throwable {
		System.setProperty("wendriver.chrome.driver", "D:\\");
		driver = new ChromeDriver();
		driver.get("http://localhost:5555/customerDetails");
		customerDetailsPage=PageFactory.initElements(driver,CustomerDetailsPage.class);
	}

	@Then("^display customer details$")
	public void display_customer_details() throws Throwable {
	}

	@When("^User inputs incorrect customer id$")
	public void user_inputs_incorrect_customer_id() throws Throwable {
	}

	@Then("^display \"([^\"]*)\" error message$")
	public void display_error_message(String arg1) throws Throwable {
	}

	@When("^User enters Wrong mobile number$")
	public void user_enters_Wrong_mobile_number() throws Throwable {
	}

	@Then("^display invalid postpaid account error message$")
	public void display_invalid_postpaid_account_error_message() throws Throwable {
	}
}
