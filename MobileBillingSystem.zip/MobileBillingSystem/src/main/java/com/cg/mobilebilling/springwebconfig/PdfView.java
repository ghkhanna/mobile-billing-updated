/*package com.cg.mobilebilling.springwebconfig;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.view.document.AbstractPdfView;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
public abstract class PdfView extends AbstractPdfView{

	protected void buildPdfDocument(Map<String, Object> arg0, Document arg1, PdfWriter arg2, HttpServletRequest arg3,
			HttpServletResponse arg4) throws Exception {
	}
	
}*/