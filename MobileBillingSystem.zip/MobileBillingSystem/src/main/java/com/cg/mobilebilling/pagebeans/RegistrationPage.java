package com.cg.mobilebilling.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {
	@FindBy(how=How.NAME, name="firstName")
	private WebElement firstName;
	
	@FindBy(how=How.NAME, name="lastName")
	private WebElement lastName;
	
	@FindBy(how=How.NAME, name="emailID")
	private WebElement emailID;
	
	@FindBy(how=How.NAME, name="dateOfBirth")
	private WebElement dateOfBirth;
	
	@FindBy(how=How.NAME, name="billingAddress.pincode")
	private WebElement pincode;
	
	@FindBy(how=How.NAME, name="billingAddress.city")
	private WebElement city;
	
	@FindBy(how=How.NAME, name="billingAddress.state")
	private WebElement state;
	
	@FindBy(how=How.NAME, name="submit")
	private WebElement button;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"firstName.errors\"]")
	private WebElement actualFirstNameErrorMessage;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"lastName.errors\"]")
	private WebElement actualLastNameErrorMessage;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"emailID.errors\"]")
	private WebElement actualEmailIDErrorMessage;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"dateOfBirth.errors\"]")
	private WebElement actualDateOfBirthErrorMessage;

	public RegistrationPage() {}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmailID() {
		return emailID.getAttribute("value");
	}

	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}

	public String getDateOfBirth() {
		return dateOfBirth.getAttribute("value");
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}

	public String getPincode() {
		return pincode.getAttribute("value");
	}

	public void setPincode(String pincode) {
		this.pincode.sendKeys(pincode);
	}

	public String getCity() {
		return city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getState() {
		return state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}
	
	public String getActualFirstNameErrorMessage() {
		return actualFirstNameErrorMessage.getText();
	}
	
	public String getActualLastNameErrorMessage() {
		return actualLastNameErrorMessage.getText();
	}
	
	public String getActualEmailIDErrorMessage() {
		return actualEmailIDErrorMessage.getText();
	}
	
	public String getActualDateOfBirthErrorMessage() {
		return actualDateOfBirthErrorMessage.getText();
	}
	
	public void clickSubmit() {
		button.submit();
	}
}
