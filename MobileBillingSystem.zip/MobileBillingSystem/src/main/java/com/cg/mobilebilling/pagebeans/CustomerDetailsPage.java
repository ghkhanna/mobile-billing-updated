package com.cg.mobilebilling.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CustomerDetailsPage {
	@FindBy(how=How.NAME, name="customerID")
	private WebElement customerID;
	
	@FindBy(how=How.NAME, name="mobileNo")
	private WebElement mobileNo;
	
	@FindBy(how=How.NAME, name="Submit")
	private WebElement button;

	public CustomerDetailsPage() {}

	public String getCustomerID() {
		return customerID.getAttribute("value");
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);;
	}

	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);;
	}

	public void clickSubmit() {
		button.submit();
	}
}
